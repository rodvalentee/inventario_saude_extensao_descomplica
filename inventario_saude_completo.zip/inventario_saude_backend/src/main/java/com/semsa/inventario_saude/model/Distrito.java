package com.semsa.inventario_saude.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("distrito")
public class Distrito {

    @Id
    private Integer id;

    private String nome;

    private String codigo;
}
