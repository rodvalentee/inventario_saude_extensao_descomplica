package com.semsa.inventario_saude.service;

import com.semsa.inventario_saude.exception.BusinessException;
import com.semsa.inventario_saude.model.TipoUnidade;
import com.semsa.inventario_saude.repository.TipoUnidadeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class TipoUnidadeService {

    private final TipoUnidadeRepository tipoUnidadeRepository;

    public Flux<TipoUnidade> listarTodos() {
        return tipoUnidadeRepository.findAll();
    }

    public Mono<TipoUnidade> buscarPorId(Integer id) {
        return tipoUnidadeRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Tipo de unidade não encontrado: ID = " + id)
                ));
    }

    public Mono<TipoUnidade> criar(TipoUnidade tipo) {
        return tipoUnidadeRepository.save(tipo);
    }

    public Mono<TipoUnidade> atualizar(Integer id, TipoUnidade novo) {
        return tipoUnidadeRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Tipo de unidade não encontrado: ID = " + id)
                ))
                .flatMap(existente -> {
                    existente.setNome(novo.getNome());
                    existente.setCodigo(novo.getCodigo());
                    return tipoUnidadeRepository.save(existente);
                });
    }

    public Mono<Void> deletar(Integer id) {
        return tipoUnidadeRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Tipo de unidade não encontrado: ID = " + id)
                ))
                .flatMap(tipoUnidadeRepository::delete);
    }
}
