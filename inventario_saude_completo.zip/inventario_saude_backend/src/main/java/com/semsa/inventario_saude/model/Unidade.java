package com.semsa.inventario_saude.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.data.relational.core.mapping.Column;

@Data
@Table("unidade")
public class Unidade {

    @Id
    private Integer id;

    private String nome;

    private String sigla;

    @Column("distrito_id")
    private Integer distritoId;

    @Column("tipo_id")
    private Integer tipoId;
}
