package com.semsa.inventario_saude;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioSaudeApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventarioSaudeApplication.class, args);
    }

}
