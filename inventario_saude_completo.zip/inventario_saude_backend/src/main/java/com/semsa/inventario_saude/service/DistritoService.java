package com.semsa.inventario_saude.service;

import com.semsa.inventario_saude.exception.BusinessException;
import com.semsa.inventario_saude.model.Distrito;
import com.semsa.inventario_saude.repository.DistritoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class DistritoService {

    private final DistritoRepository distritoRepository;

    public Flux<Distrito> listarTodos() {
        return distritoRepository.findAll();
    }

    public Mono<Distrito> buscarPorId(Integer id) {
        return distritoRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Distrito não encontrado: ID = " + id)
                ));
    }

    public Mono<Distrito> criar(Distrito distrito) {
        // Aqui você poderia validar código único, se quiser
        return distritoRepository.save(distrito);
    }

    public Mono<Distrito> atualizar(Integer id, Distrito novo) {
        return distritoRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Distrito não encontrado: ID = " + id)
                ))
                .flatMap(existente -> {
                    existente.setNome(novo.getNome());
                    existente.setCodigo(novo.getCodigo());
                    return distritoRepository.save(existente);
                });
    }

    public Mono<Void> deletar(Integer id) {
        return distritoRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Distrito não encontrado: ID = " + id)
                ))
                .flatMap(distritoRepository::delete);
    }
}
