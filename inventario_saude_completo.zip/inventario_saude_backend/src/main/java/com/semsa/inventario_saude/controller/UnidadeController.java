package com.semsa.inventario_saude.controller;

import com.semsa.inventario_saude.model.Unidade;
import com.semsa.inventario_saude.service.UnidadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/unidades")
@RequiredArgsConstructor
public class UnidadeController {

    private final UnidadeService unidadeService;

    @GetMapping
    public Flux<Unidade> listarTodas() {
        return unidadeService.listarTodas();
    }

    @GetMapping("/{id}")
    public Mono<Unidade> buscarPorId(@PathVariable Integer id) {
        return unidadeService.buscarPorId(id);
    }

    @GetMapping("/por-distrito/{distritoId}")
    public Flux<Unidade> listarPorDistrito(@PathVariable Integer distritoId) {
        return unidadeService.listarPorDistrito(distritoId);
    }

    @GetMapping("/por-tipo/{tipoId}")
    public Flux<Unidade> listarPorTipo(@PathVariable Integer tipoId) {
        return unidadeService.listarPorTipo(tipoId);
    }

    @PostMapping
    public Mono<Unidade> criar(@RequestBody Unidade unidade) {
        return unidadeService.criar(unidade);
    }

    @PutMapping("/{id}")
    public Mono<Unidade> atualizar(@PathVariable Integer id,
                                   @RequestBody Unidade unidade) {
        return unidadeService.atualizar(id, unidade);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deletar(@PathVariable Integer id) {
        return unidadeService.deletar(id);
    }
}
