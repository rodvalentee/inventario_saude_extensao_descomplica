package com.semsa.inventario_saude.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("tipo_unidade")
public class TipoUnidade {

    @Id
    private Integer id;

    private String nome;

    private String codigo;
}
