package com.semsa.inventario_saude.controller;

import com.semsa.inventario_saude.model.TipoUnidade;
import com.semsa.inventario_saude.service.TipoUnidadeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/tipos-unidade")
@RequiredArgsConstructor
public class TipoUnidadeController {

    private final TipoUnidadeService tipoUnidadeService;

    @GetMapping
    public Flux<TipoUnidade> listarTodos() {
        return tipoUnidadeService.listarTodos();
    }

    @GetMapping("/{id}")
    public Mono<TipoUnidade> buscarPorId(@PathVariable Integer id) {
        return tipoUnidadeService.buscarPorId(id);
    }

    @PostMapping
    public Mono<TipoUnidade> criar(@RequestBody TipoUnidade tipo) {
        return tipoUnidadeService.criar(tipo);
    }

    @PutMapping("/{id}")
    public Mono<TipoUnidade> atualizar(@PathVariable Integer id,
                                       @RequestBody TipoUnidade tipo) {
        return tipoUnidadeService.atualizar(id, tipo);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deletar(@PathVariable Integer id) {
        return tipoUnidadeService.deletar(id);
    }
}
