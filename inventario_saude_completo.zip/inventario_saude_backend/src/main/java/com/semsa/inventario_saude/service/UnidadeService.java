package com.semsa.inventario_saude.service;

import com.semsa.inventario_saude.exception.BusinessException;
import com.semsa.inventario_saude.model.Unidade;
import com.semsa.inventario_saude.repository.DistritoRepository;
import com.semsa.inventario_saude.repository.TipoUnidadeRepository;
import com.semsa.inventario_saude.repository.UnidadeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class UnidadeService {

    private final UnidadeRepository unidadeRepository;
    private final DistritoRepository distritoRepository;
    private final TipoUnidadeRepository tipoUnidadeRepository;

    public Flux<Unidade> listarTodas() {
        return unidadeRepository.findAll();
    }

    public Mono<Unidade> buscarPorId(Integer id) {
        return unidadeRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Unidade não encontrada: ID = " + id)
                ));
    }

    public Flux<Unidade> listarPorDistrito(Integer distritoId) {
        return unidadeRepository.findByDistritoId(distritoId);
    }

    public Flux<Unidade> listarPorTipo(Integer tipoId) {
        return unidadeRepository.findByTipoId(tipoId);
    }

    public Mono<Unidade> criar(Unidade unidade) {
        // Validar existência de distrito e tipo
        Mono<Void> validaDistrito = distritoRepository.findById(unidade.getDistritoId())
                .switchIfEmpty(Mono.error(
                        new BusinessException("Distrito inválido para unidade.")
                ))
                .then();

        Mono<Void> validaTipo = tipoUnidadeRepository.findById(unidade.getTipoId())
                .switchIfEmpty(Mono.error(
                        new BusinessException("Tipo de unidade inválido.")
                ))
                .then();

        // Validar sigla única
        Mono<Void> validaSigla = unidadeRepository.findBySigla(unidade.getSigla())
                .flatMap(existente -> Mono.<Void>error(
                        new BusinessException("A sigla '" + unidade.getSigla() + "' já está em uso.")
                ))
                .switchIfEmpty(Mono.empty());

        return Mono.when(validaDistrito, validaTipo, validaSigla)
                .then(unidadeRepository.save(unidade));
    }

    public Mono<Unidade> atualizar(Integer id, Unidade novaUnidade) {
        return unidadeRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Unidade não encontrada: ID = " + id)
                ))
                .flatMap(existente -> {
                    Mono<Void> validaDistrito = distritoRepository.findById(novaUnidade.getDistritoId())
                            .switchIfEmpty(Mono.error(
                                    new BusinessException("Distrito inválido para unidade.")
                            ))
                            .then();

                    Mono<Void> validaTipo = tipoUnidadeRepository.findById(novaUnidade.getTipoId())
                            .switchIfEmpty(Mono.error(
                                    new BusinessException("Tipo de unidade inválido.")
                            ))
                            .then();

                    Mono<Void> validaSigla;
                    if (!existente.getSigla().equals(novaUnidade.getSigla())) {
                        validaSigla = unidadeRepository.findBySigla(novaUnidade.getSigla())
                                .flatMap(u -> Mono.<Void>error(
                                        new BusinessException("A sigla '" + novaUnidade.getSigla() + "' já está em uso.")
                                ))
                                .switchIfEmpty(Mono.empty());
                    } else {
                        validaSigla = Mono.empty();
                    }

                    return Mono.when(validaDistrito, validaTipo, validaSigla)
                            .then(Mono.defer(() -> {
                                existente.setNome(novaUnidade.getNome());
                                existente.setSigla(novaUnidade.getSigla());
                                existente.setDistritoId(novaUnidade.getDistritoId());
                                existente.setTipoId(novaUnidade.getTipoId());
                                return unidadeRepository.save(existente);
                            }));
                });
    }

    public Mono<Void> deletar(Integer id) {
        return unidadeRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Unidade não encontrada: ID = " + id)
                ))
                .flatMap(unidadeRepository::delete);
    }
}
