package com.semsa.inventario_saude.repository;

import com.semsa.inventario_saude.model.Unidade;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

public interface UnidadeRepository extends ReactiveCrudRepository<Unidade, Integer> {

    Mono<Unidade> findBySigla(String sigla);

    Flux<Unidade> findByDistritoId(Integer distritoId);

    Flux<Unidade> findByTipoId(Integer tipoId);
}
