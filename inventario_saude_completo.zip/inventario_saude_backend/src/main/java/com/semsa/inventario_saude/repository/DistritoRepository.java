package com.semsa.inventario_saude.repository;

import com.semsa.inventario_saude.model.Distrito;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface DistritoRepository extends ReactiveCrudRepository<Distrito, Integer> {
}
