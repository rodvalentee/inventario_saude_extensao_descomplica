package com.semsa.inventario_saude.controller;

import com.semsa.inventario_saude.dto.CreateMaquinaRequest;
import com.semsa.inventario_saude.exception.BusinessException;
import com.semsa.inventario_saude.model.Maquina;
import com.semsa.inventario_saude.service.MaquinaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/maquinas")
@RequiredArgsConstructor
public class MaquinaController {

    private final MaquinaService maquinaService;

    // 🔹 Criar máquina com nome automático
    @PostMapping("/gerar")
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<Maquina> gerar(@RequestBody CreateMaquinaRequest request) {
        return maquinaService.gerarMaquina(request);
    }

    // 🔹 Listar todas as máquinas
    @GetMapping
    public Flux<Maquina> listar() {
        return maquinaService.listarTodas();
    }

    // 🔹 Buscar por ID
    @GetMapping("/{id}")
    public Mono<Maquina> buscarPorId(@PathVariable Integer id) {
        return maquinaService.buscarPorId(id);
    }

    @GetMapping("/tombo/{tombo}")
    public Mono<Maquina> buscarPorTombo(@PathVariable String tombo) {
        return maquinaService.buscarPorTombo(tombo);
    }

    // 🔹 Buscar por nome (exato)
    @GetMapping("/por-nome")
    public Flux<Maquina> buscarPorNome(@RequestParam String nome) {
        return maquinaService.buscarPorNome(nome);
    }

    // 🔹 Buscar por unidade
    @GetMapping("/por-unidade")
    public Flux<Maquina> buscarPorUnidade(@RequestParam Integer unidadeId) {
        return maquinaService.buscarPorUnidade(unidadeId);
    }

    // 🔹 Desassociar (liberar número e tombo)
    @PostMapping("/{id}/desassociar")
    public Mono<Maquina> desassociar(@PathVariable Integer id) {
        return maquinaService.desassociar(id);
    }

    // 🔹 Tratamento elegante de erros de regra de negócio
    @ExceptionHandler(BusinessException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Mono<String> handleBusinessException(BusinessException ex) {
        return Mono.just(ex.getMessage());
    }
}
