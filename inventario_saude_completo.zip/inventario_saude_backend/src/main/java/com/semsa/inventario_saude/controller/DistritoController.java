package com.semsa.inventario_saude.controller;

import com.semsa.inventario_saude.model.Distrito;
import com.semsa.inventario_saude.service.DistritoService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/distritos")
@RequiredArgsConstructor
public class DistritoController {

    private final DistritoService distritoService;

    @GetMapping
    public Flux<Distrito> listarTodos() {
        return distritoService.listarTodos();
    }

    @GetMapping("/{id}")
    public Mono<Distrito> buscarPorId(@PathVariable Integer id) {
        return distritoService.buscarPorId(id);
    }

    @PostMapping
    public Mono<Distrito> criar(@RequestBody Distrito distrito) {
        return distritoService.criar(distrito);
    }

    @PutMapping("/{id}")
    public Mono<Distrito> atualizar(@PathVariable Integer id,
                                    @RequestBody Distrito distrito) {
        return distritoService.atualizar(id, distrito);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deletar(@PathVariable Integer id) {
        return distritoService.deletar(id);
    }
}
