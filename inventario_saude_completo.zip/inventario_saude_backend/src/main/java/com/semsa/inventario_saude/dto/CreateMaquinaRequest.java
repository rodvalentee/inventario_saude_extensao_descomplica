package com.semsa.inventario_saude.dto;

import lombok.Data;

@Data
public class CreateMaquinaRequest {

    private Integer unidadeId;   // ID da unidade/setor
    private String tombo;        // tombo ou número de série (obrigatório)
    private Boolean ehEmenda;    // true = EF, false = normal
}
