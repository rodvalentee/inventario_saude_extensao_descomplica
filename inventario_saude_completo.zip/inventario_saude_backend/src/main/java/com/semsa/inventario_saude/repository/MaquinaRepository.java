package com.semsa.inventario_saude.repository;

import com.semsa.inventario_saude.model.Maquina;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface MaquinaRepository extends ReactiveCrudRepository<Maquina, Integer> {

    Mono<Maquina> findByTombo(String tombo);

    Flux<Maquina> findAllByUnidadeId(Integer unidadeId);

    Flux<Maquina> findAllByUnidadeIdAndEhEmenda(Integer unidadeId, Boolean ehEmenda);

    Flux<Maquina> findByNomeGerado(String nomeGerado);
}
