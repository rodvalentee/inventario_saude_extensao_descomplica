package com.semsa.inventario_saude.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.data.relational.core.mapping.Column;

import java.time.LocalDateTime;

@Data
@Table("maquina")
public class Maquina {

    @Id
    private Integer id;

    @Column("nome_gerado")
    private String nomeGerado;

    private Integer numero;

    @Column("eh_emenda")
    private Boolean ehEmenda;

    private String tombo;

    @Column("data_criacao")
    private LocalDateTime dataCriacao;

    @Column("unidade_id")
    private Integer unidadeId;

    @Column("distrito_id")
    private Integer distritoId;

    @Column("tipo_id")
    private Integer tipoId;
}
