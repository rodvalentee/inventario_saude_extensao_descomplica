package com.semsa.inventario_saude.repository;

import com.semsa.inventario_saude.model.TipoUnidade;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface TipoUnidadeRepository extends ReactiveCrudRepository<TipoUnidade, Integer> {
}
