package com.semsa.inventario_saude.service;

import com.semsa.inventario_saude.dto.CreateMaquinaRequest;
import com.semsa.inventario_saude.exception.BusinessException;
import com.semsa.inventario_saude.model.Distrito;
import com.semsa.inventario_saude.model.Maquina;
import com.semsa.inventario_saude.model.TipoUnidade;
import com.semsa.inventario_saude.model.Unidade;
import com.semsa.inventario_saude.repository.DistritoRepository;
import com.semsa.inventario_saude.repository.MaquinaRepository;
import com.semsa.inventario_saude.repository.TipoUnidadeRepository;
import com.semsa.inventario_saude.repository.UnidadeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MaquinaService {

    private final MaquinaRepository maquinaRepository;
    private final UnidadeRepository unidadeRepository;
    private final DistritoRepository distritoRepository;
    private final TipoUnidadeRepository tipoUnidadeRepository;

    // 🔹 Gera a máquina (tombo + número + nome)
        public Mono<Maquina> gerarMaquina(CreateMaquinaRequest request) {

            if (request.getUnidadeId() == null) {
                return Mono.error(new BusinessException("Unidade é obrigatória."));
            }
            if (request.getTombo() == null || request.getTombo().isBlank()) {
                return Mono.error(new BusinessException("Tombo (ou número de série) é obrigatório."));
            }

            boolean ehEmenda = Boolean.TRUE.equals(request.getEhEmenda());

            return maquinaRepository.findByTombo(request.getTombo())
                    .flatMap(existente ->
                            Mono.error(new BusinessException(
                                    "Já existe uma máquina associada ao tombo: " + request.getTombo()))
                    )
                    .switchIfEmpty(
                            unidadeRepository.findById(request.getUnidadeId())
                                    .switchIfEmpty(Mono.error(new BusinessException(
                                            "Unidade não encontrada: ID = " + request.getUnidadeId()
                                    )))
                                    .flatMap(unidade ->
                                            maquinaRepository
                                                    .findAllByUnidadeIdAndEhEmenda(unidade.getId(), ehEmenda)
                                                    .filter(m -> m.getNumero() != null)   // IGNORA máquinas desassociadas
                                                    .map(Maquina::getNumero)
                                                    .collectList()
                                                    .flatMap(nums ->
                                                            gerarNovaMaquina(unidade, nums, request.getTombo(), ehEmenda)
                                                    )
                                    )
                    )
                    .cast(Maquina.class);
        }

    private Mono<Maquina> gerarNovaMaquina(Unidade unidade,
                                           List<Integer> numerosUsados,
                                           String tombo,
                                           boolean ehEmenda) {

        int proximoNumero = calcularProximoNumero(numerosUsados, ehEmenda);
        String numeroFormatado = String.format("%03d", proximoNumero);

        Mono<Distrito> distritoMono = distritoRepository.findById(unidade.getDistritoId())
                .switchIfEmpty(Mono.error(
                        new BusinessException("Distrito não encontrado para unidade ID = " + unidade.getId())
                ));

        Mono<TipoUnidade> tipoMono = tipoUnidadeRepository.findById(unidade.getTipoId())
                .switchIfEmpty(Mono.error(
                        new BusinessException("Tipo de unidade não encontrado para unidade ID = " + unidade.getId())
                ));

        return Mono.zip(distritoMono, tipoMono)
                .flatMap(tuple -> {
                    Distrito distrito = tuple.getT1();
                    TipoUnidade tipo = tuple.getT2();

                    String nomeGerado = distrito.getCodigo()
                            + "-" +
                            tipo.getCodigo()
                            + unidade.getSigla()
                            + "-" +
                            numeroFormatado +
                            (ehEmenda ? "ef" : "");

                    Maquina m = new Maquina();
                    m.setEhEmenda(ehEmenda);
                    m.setNumero(proximoNumero);
                    m.setTombo(tombo);
                    m.setNomeGerado(nomeGerado);
                    m.setUnidadeId(unidade.getId());
                    m.setDistritoId(unidade.getDistritoId());
                    m.setTipoId(unidade.getTipoId());

                    return maquinaRepository.save(m);
                });
    }

    // 🔹 Calcula o menor número disponível
    private int calcularProximoNumero(List<Integer> usados, boolean ehEmenda) {
        int inicio = ehEmenda ? 200 : 1;

        if (usados == null || usados.isEmpty()) {
            return inicio;
        }

        int atual = inicio;

        while (true) {
            boolean existe = false;

            for (Integer n : usados) {
                if (n != null && n.equals(atual)) {
                    existe = true;
                    break;
                }
            }

            if (!existe) return atual;
            atual++;
        }
    }

    // 🔹 Listar todas as máquinas
    public Flux<Maquina> listarTodas() {
        return maquinaRepository.findAll();
    }

    // 🔹 Buscar por ID
    public Mono<Maquina> buscarPorId(Integer id) {
        return maquinaRepository.findById(id)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Máquina não encontrada: ID = " + id)
                ));
    }

    // 🔹 Buscar por tombo
    public Mono<Maquina> buscarPorTombo(String tombo) {
        return maquinaRepository.findByTombo(tombo)
                .switchIfEmpty(Mono.error(
                        new BusinessException("Máquina não encontrada para o tombo: " + tombo)
                ));
    }

    // 🔹 Buscar por nome
    public Flux<Maquina> buscarPorNome(String nome) {
        return maquinaRepository.findByNomeGerado(nome);
    }

    // 🔹 Buscar por unidade
    public Flux<Maquina> buscarPorUnidade(Integer unidadeId) {
        return maquinaRepository.findAllByUnidadeId(unidadeId);
    }

    // 🔹 Desassociar máquina
    public Mono<Maquina> desassociar(Integer id) {
        return maquinaRepository.findById(id)
                .switchIfEmpty(Mono.error(new BusinessException("Máquina não encontrada: ID = " + id)))
                .flatMap(maquina -> {
                    maquina.setNomeGerado(null);
                    maquina.setNumero(null);
                    maquina.setTombo(null);
                    return maquinaRepository.save(maquina);
                });
    }
}
