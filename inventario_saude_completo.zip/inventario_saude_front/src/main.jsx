import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";

import Home from "./pages/Home";
import CadastrarUnidade from "./pages/CadastrarUnidade";
import CadastrarMaquina from "./pages/CadastrarMaquina";
import BuscarTombo from "./pages/BuscarTombo";
import BuscarNome from "./pages/BuscarNome";
import ListarMaquinas from "./pages/ListarMaquinas";
import Desassociar from "./pages/Desassociar";

import "./styles/global.css";

function Main() {
    return (
        <BrowserRouter>
            <Navbar />

            <div className="container">
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/cadastrar-unidade" element={<CadastrarUnidade />} />
                    <Route path="/cadastrar-maquina" element={<CadastrarMaquina />} />
                    <Route path="/buscar-tombo" element={<BuscarTombo />} />
                    <Route path="/buscar-nome" element={<BuscarNome />} />
                    <Route path="/listar-maquinas" element={<ListarMaquinas />} />
                    <Route path="/desassociar" element={<Desassociar />} />
                </Routes>
            </div>
        </BrowserRouter>
    );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Main />);
