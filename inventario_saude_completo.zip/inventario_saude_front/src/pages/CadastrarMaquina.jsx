import React, { useEffect, useState } from "react";

export default function CadastrarMaquina() {
    const [unidades, setUnidades] = useState([]);
    const [unidadeId, setUnidadeId] = useState("");
    const [tombo, setTombo] = useState("");
    const [ehEmenda, setEhEmenda] = useState(false);
    const [resultado, setResultado] = useState("");

    useEffect(() => {
        fetch("http://localhost:8080/unidades")
            .then((r) => r.json())
            .then((d) => setUnidades(d));
    }, []);

    const gerar = async () => {
        const resp = await fetch("http://localhost:8080/maquinas/gerar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ unidadeId, tombo, ehEmenda }),
        });

        const data = await resp.json();
        setResultado(JSON.stringify(data, null, 2));
    };

    return (
        <div>
            <h1>Cadastrar Máquina</h1>

            <label>Unidade:</label>
            <select onChange={(e) => setUnidadeId(e.target.value)}>
                <option value="">Selecione uma unidade</option>
                {unidades.map((u) => (
                    <option key={u.id} value={u.id}>{u.nome} ({u.sigla})</option>
                ))}
            </select>

            <br />

            <label>Tombo:</label>
            <input value={tombo} onChange={(e) => setTombo(e.target.value)} />

            <br />

            <label>
                <div className="checkbox-group">
                    <input
                        type="checkbox"
                        checked={ehEmenda}
                        onChange={(e) => setEhEmenda(e.target.checked)}
                    />
                    <label>É emenda parlamentar</label>
                </div>
            </label>

            <br />

            <button onClick={gerar}>Gerar Nome</button>

            <pre>{resultado}</pre>
        </div>
    );
}
