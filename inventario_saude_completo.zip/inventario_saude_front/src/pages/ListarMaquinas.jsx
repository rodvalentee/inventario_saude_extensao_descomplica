import { useEffect, useState } from "react";

export default function ListarMaquinas() {
    const [maquinas, setMaquinas] = useState([]);
    const [unidades, setUnidades] = useState([]);

    useEffect(() => {
        fetch("http://localhost:8080/maquinas")
            .then(res => res.json())
            .then(data => setMaquinas(data));

        fetch("http://localhost:8080/unidades")
            .then(res => res.json())
            .then(data => setUnidades(data));
    }, []);

    // 🔹 Função para obter nome da unidade em MAIÚSCULO
    const nomeDaUnidade = (id) => {
        const u = unidades.find(u => u.id === id);
        return u ? u.nome.toUpperCase() : "UNIDADE NÃO ENCONTRADA";
    };

    // 🔹 Agrupa máquinas por unidadeId
    const maquinasPorUnidade = maquinas.reduce((acc, maquina) => {
        if (!acc[maquina.unidadeId]) acc[maquina.unidadeId] = [];
        acc[maquina.unidadeId].push(maquina);
        return acc;
    }, {});

    return (
        <div className="container">
            <h1>Lista de Máquinas</h1>

            {Object.keys(maquinasPorUnidade).map(unidadeId => (
                <div key={unidadeId} className="card">
                    <h2>Unidade: {nomeDaUnidade(parseInt(unidadeId))}</h2>

                    {maquinasPorUnidade[unidadeId].map(m => (
                        <div className="machine-item" key={m.id}>
                            <span className="machine-name">
                                {m.nomeGerado?.toUpperCase()}
                            </span>

                            <span className="machine-tombo">
                                TOMBO: {m.tombo?.toUpperCase() || "—"}
                            </span>
                        </div>
                    ))}
                </div>
            ))}
        </div>
    );
}
