import React, { useEffect, useState } from "react";

export default function CadastrarUnidade() {
    const [nome, setNome] = useState("");
    const [sigla, setSigla] = useState("");
    const [distritoId, setDistritoId] = useState("");
    const [tipoId, setTipoId] = useState("");

    const [distritos, setDistritos] = useState([]);
    const [tipos, setTipos] = useState([]);

    const [mensagem, setMensagem] = useState("");

    // 🔹 Carregar distritos e tipos ao abrir a página
    useEffect(() => {
        fetch("http://localhost:8080/distritos")
            .then((res) => res.json())
            .then((data) => setDistritos(data))
            .catch((err) => console.error("Erro ao carregar distritos:", err));

        fetch("http://localhost:8080/tipos-unidade")
            .then((res) => res.json())
            .then((data) => setTipos(data))
            .catch((err) => console.error("Erro ao carregar tipos:", err));
    }, []);

    // 🔹 Envio do formulário
    function cadastrarUnidade() {
        const req = { nome, sigla, distritoId, tipoId };

        fetch("http://localhost:8080/unidades", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(req),
        })
            .then(async (res) => {
                const texto = await res.text();

                if (!res.ok) {
                    setMensagem("❌ " + texto);
                    return;
                }

                setMensagem("✅ Unidade cadastrada com sucesso!");
                setNome("");
                setSigla("");
                setDistritoId("");
                setTipoId("");
            })
            .catch(() => setMensagem("❌ Erro na requisição"));
    }

    return (
        <div className="card">
            <h2>Cadastrar Unidade</h2>

            {mensagem && (
                <div
                    style={{
                        background: "#eef",
                        padding: "10px",
                        marginBottom: "15px",
                        borderRadius: "6px",
                    }}
                >
                    {mensagem}
                </div>
            )}

            {/* NOME */}
            <label>Nome:</label>
            <input
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                className="input"
                placeholder="Nome da unidade..."
            />

            {/* SIGLA */}
            <label>Sigla:</label>
            <input
                value={sigla}
                onChange={(e) => setSigla(e.target.value)}
                className="input"
                placeholder="Ex.: bm"
            />

            {/* DISTRITO */}
            <label>Distrito:</label>
            <select
                className="input"
                value={distritoId}
                onChange={(e) => setDistritoId(e.target.value)}
            >
                <option value="">Selecione</option>
                {distritos.map((d) => (
                    <option key={d.id} value={d.id}>
                        ({d.codigo}) {d.nome}
                    </option>
                ))}
            </select>

            {/* TIPO UNIDADE */}
            <label>Tipo da Unidade:</label>
            <select
                className="input"
                value={tipoId}
                onChange={(e) => setTipoId(e.target.value)}
            >
                <option value="">Selecione</option>
                {tipos.map((t) => (
                    <option key={t.id} value={t.id}>
                        ({t.codigo}) {t.nome}
                    </option>
                ))}
            </select>

            <button onClick={cadastrarUnidade} className="btn">
                Cadastrar
            </button>
        </div>
    );
}
