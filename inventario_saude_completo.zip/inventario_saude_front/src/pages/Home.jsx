import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
    return (
        <div>
            <h1>Inventário de Máquinas — SEMSA</h1>

            <ul>
                <li><Link to="/cadastrar-maquina">Cadastrar Máquina</Link></li>
                <li><Link to="/buscar-tombo">Buscar por Tombo</Link></li>
                <li><Link to="/buscar-nome">Buscar por Nome</Link></li>
                <li><Link to="/listar-maquinas">Listar Máquinas</Link></li>
                <li><Link to="/desassociar">Desassociar Máquina</Link></li>
                <li><Link to="/cadastrar-unidade">Cadastrar Unidade</Link></li>
            </ul>
        </div>
    );
}
