import React, { useState } from "react";

export default function BuscarNome() {
    const [nome, setNome] = useState("");
    const [resultado, setResultado] = useState([]);

    const buscar = async () => {
        const resp = await fetch(`http://localhost:8080/maquinas/nome/${nome}`);
        const data = await resp.json();
        setResultado(data);
    };

    return (
        <div>
            <h1>Buscar por Nome</h1>

            <input
                placeholder="Digite parte do nome"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
            />

            <button onClick={buscar}>Buscar</button>

            <ul>
                {resultado.map((m) => (
                    <li key={m.id}>
                        {m.nomeGerado} — Tombo: {m.tombo}
                    </li>
                ))}
            </ul>
        </div>
    );
}
