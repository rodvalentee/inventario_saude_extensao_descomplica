import { useState } from "react";

export default function BuscarTombo() {
    const [tombo, setTombo] = useState("");
    const [resultado, setResultado] = useState(null);
    const [erro, setErro] = useState("");

    const buscar = async () => {
        setErro("");
        setResultado(null);

        if (!tombo.trim()) {
            setErro("Digite um tombo para pesquisar.");
            return;
        }

        try {
            const r = await fetch(`http://localhost:8080/maquinas/tombo/${tombo}`);
            if (!r.ok) {
                throw new Error("Máquina não encontrada.");
            }
            const data = await r.json();
            setResultado(data);
        } catch (e) {
            setErro(e.message);
        }
    };

    return (
        <div className="card">
            <h1 className="title">Buscar por Tombo</h1>

            <label className="label">Tombo:</label>
            <input
                className="input"
                value={tombo}
                onChange={(e) => setTombo(e.target.value)}
                placeholder="Digite o tombo"
            />

            <button className="button" onClick={buscar}>
                Buscar
            </button>

            {erro && <p className="error">{erro}</p>}

            {resultado && (
                <div className="result-box">
                    <p><b>ID:</b> {resultado.id}</p>
                    <p><b>Nome:</b> {resultado.nome}</p>
                    <p><b>Tombo:</b> {resultado.tombo}</p>
                    <p><b>Unidade:</b> {resultado.unidade?.nome}</p>
                    <p><b>É emenda:</b> {resultado.ehEmenda ? "Sim" : "Não"}</p>
                </div>
            )}
        </div>
    );
}
