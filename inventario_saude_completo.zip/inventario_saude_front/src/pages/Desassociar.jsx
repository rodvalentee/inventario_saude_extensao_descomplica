import React, { useState } from "react";

export default function Desassociar() {
    const [id, setId] = useState("");
    const [resultado, setResultado] = useState("");

    const desassociar = async () => {
        const resp = await fetch(`http://localhost:8080/maquinas/${id}/desassociar`, {
            method: "POST",
        });

        const data = await resp.json();
        setResultado(JSON.stringify(data, null, 2));
    };

    return (
        <div>
            <h1>Desassociar Máquina</h1>

            <label>ID da máquina:</label>
            <input value={id} onChange={(e) => setId(e.target.value)} />

            <button onClick={desassociar}>Desassociar</button>

            <pre>{resultado}</pre>
        </div>
    );
}
