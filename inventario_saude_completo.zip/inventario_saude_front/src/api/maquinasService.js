// src/api/maquinasService.js

const API_URL = "http://localhost:8080";

export async function gerarMaquina(data) {
    const resp = await fetch(`${API_URL}/maquinas/gerar`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    });

    if (!resp.ok) {
        const text = await resp.text();
        throw new Error(text || "Erro ao gerar máquina");
    }

    return await resp.json();
}

export async function listarUnidades() {
    const resp = await fetch(`${API_URL}/unidades`);
    if (!resp.ok) throw new Error("Erro ao buscar unidades");
    return await resp.json();
}
