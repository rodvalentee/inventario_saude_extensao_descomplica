// src/components/SelectUnidade.jsx
import { useEffect, useState } from "react";
import { listarUnidades } from "../api/maquinasService";

export default function SelectUnidade({ value, onChange }) {
    const [unidades, setUnidades] = useState([]);

    useEffect(() => {
        listarUnidades().then(setUnidades);
    }, []);

    return (
        <select value={value} onChange={e => onChange(e.target.value)}>
            <option value="">Selecione uma unidade</option>
            {unidades.map(u => (
                <option key={u.id} value={u.id}>
                    {u.nome} ({u.sigla})
                </option>
            ))}
        </select>
    );
}
