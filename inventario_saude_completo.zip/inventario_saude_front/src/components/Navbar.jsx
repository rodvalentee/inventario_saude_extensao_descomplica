import { Link } from "react-router-dom";

export default function Navbar() {
    return (
        <nav className="navbar">
            <Link to="/">Início</Link>
            <Link to="/cadastrar-unidade">Cadastrar Unidade</Link>
            <Link to="/cadastrar-maquina">Cadastrar Máquina</Link>
            <Link to="/buscar-tombo">Buscar Tombo</Link>
            <Link to="/buscar-nome">Buscar Nome</Link>
            <Link to="/listar-maquinas">Listar Máquinas</Link>
            <Link to="/desassociar">Desassociar</Link>
        </nav>
    );
}
